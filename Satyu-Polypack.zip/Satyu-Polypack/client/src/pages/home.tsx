import Navbar from "@/components/sections/Navbar";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Products from "@/components/sections/Products";
import Manufacturing from "@/components/sections/Manufacturing";
import Export from "@/components/sections/Export";
import Contact from "@/components/sections/Contact";
import Footer from "@/components/sections/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Products />
        <Manufacturing />
        <Export />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
