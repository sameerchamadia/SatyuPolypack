import { Factory } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-gray-400 py-12 border-t border-slate-800">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              <span className="text-2xl font-heading font-bold text-white tracking-tight">SATYU POLYPACK</span>
            </div>
            <p className="text-sm max-w-md">
              Reliable plastic packaging manufacturer and exporter. Committed to quality, consistency, and global partnerships.
            </p>
          </div>
          
          <div className="flex gap-8 text-sm font-medium">
             <a href="#" className="hover:text-white transition-colors">Home</a>
             <a href="#products" className="hover:text-white transition-colors">Products</a>
             <a href="#about" className="hover:text-white transition-colors">About</a>
             <a href="#contact" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs">
          <p>&copy; {currentYear} Satyu Polypack. All rights reserved.</p>
          <p className="mt-2 md:mt-0">Manufactured in Daman, India.</p>
        </div>
      </div>
    </footer>
  );
}
