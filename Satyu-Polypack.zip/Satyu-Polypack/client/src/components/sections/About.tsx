import { motion } from "framer-motion";
import { Factory, Award, Globe, ShieldCheck } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const capabilities = [
  {
    icon: Factory,
    title: "Large-Scale Manufacturing",
    description: "High-volume production capacity from our state-of-the-art facility in Daman."
  },
  {
    icon: ShieldCheck,
    title: "Strict Quality Control",
    description: "Rigorous testing and quality assurance protocols at every stage of production."
  },
  {
    icon: Award,
    title: "Custom Specifications",
    description: "Tailored sizes, thickness, and printing options to meet specific client needs."
  },
  {
    icon: Globe,
    title: "Reliable Global Supply",
    description: "Seamless export logistics and documentation for international partners."
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.6 }}
          >
            <h4 className="text-primary font-bold uppercase tracking-widest mb-2">Who We Are</h4>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-6">
              Your Strategic Partner in <br/>Plastic Packaging
            </h2>
            <div className="w-20 h-1 bg-accent mb-8"></div>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Satyu Polypack is a Daman-based manufacturer specializing in plastic packaging solutions designed for commercial, industrial, and export markets.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Founded by Siraj Chamadiya, our mission is to provide consistent quality and reliable supply chains for distributors and wholesalers worldwide. We don't just sell bags; we deliver manufacturing reliability.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {capabilities.map((cap, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full border-none shadow-lg hover:shadow-xl transition-shadow bg-slate-50">
                  <CardContent className="p-6 flex flex-col items-start">
                    <div className="p-3 bg-white rounded-lg shadow-sm mb-4 text-primary">
                      <cap.icon size={32} strokeWidth={1.5} />
                    </div>
                    <h3 className="text-xl font-heading font-bold text-slate-900 mb-2">{cap.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{cap.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
