import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

// Import generated product images
import imgGarbage from "@assets/generated_images/industrial_garbage_bags_rolls.png";
import imgShopping from "@assets/generated_images/hdpe_shopping_bags_stack.png";
import imgLiners from "@assets/generated_images/industrial_plastic_liners.png";
import imgStretch from "@assets/generated_images/industrial_stretch_wrap_rolls.png";

const products = [
  {
    id: 1,
    title: "Garbage Bags",
    description: "Heavy-duty trash bags for industrial and commercial use. Available in small to extra-large sizes (e.g., 30 × 37 inch XL).",
    image: imgGarbage,
    tags: ["HDPE/LDPE", "Rolls or Flat", "Custom Colors"]
  },
  {
    id: 2,
    title: "Shopping Bags",
    description: "High-quality printed D-Cut & W-Cut bags. Durable construction suitable for retail and grocery distribution.",
    image: imgShopping,
    tags: ["Printed", "D-Cut", "W-Cut", "Various Microns"]
  },
  {
    id: 3,
    title: "Industrial Liners",
    description: "Strong LDPE & HDPE liners with 5kg–10kg capacity. Perfect for cartons, drums, and heavy-duty containment.",
    image: imgLiners,
    tags: ["Food Grade", "Leak Proof", "High Clarity"]
  },
  {
    id: 4,
    title: "Stretch Wrap & Biohazard",
    description: "Secure packaging solutions including industrial stretch film and specialized biohazard waste bags.",
    image: imgStretch,
    tags: ["High Elongation", "Puncture Resistant", "Safety Compliant"]
  }
];

export default function Products() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="products" className="py-24 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h4 className="text-primary font-bold uppercase tracking-widest mb-2">Our Product Range</h4>
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-4">
            Industrial Grade Packaging
          </h2>
          <p className="text-gray-600 text-lg">
            Built for performance and reliability. We specialize in bulk manufacturing with custom sizes, thickness, and printing options available.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-white rounded-none border border-gray-100 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col sm:flex-row h-full"
            >
              <div className="sm:w-2/5 h-64 sm:h-auto overflow-hidden relative">
                <img 
                  src={product.image} 
                  alt={product.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-slate-900/10 group-hover:bg-transparent transition-colors" />
              </div>
              
              <div className="p-8 sm:w-3/5 flex flex-col justify-between">
                <div>
                  <h3 className="text-2xl font-heading font-bold text-slate-900 mb-3 group-hover:text-primary transition-colors">
                    {product.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {product.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {product.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="rounded-sm bg-slate-100 text-slate-700 font-normal">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="mt-auto">
                  <Button 
                    variant="link" 
                    onClick={scrollToContact}
                    className="p-0 text-primary font-semibold hover:text-accent group/btn"
                  >
                    Request Bulk Quote <ArrowUpRight className="ml-1 h-4 w-4 transform group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
