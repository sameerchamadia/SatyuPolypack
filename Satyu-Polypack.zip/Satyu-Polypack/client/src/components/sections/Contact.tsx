import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send } from "lucide-react";

const formSchema = z.object({
  companyName: z.string().min(2, "Company name is required"),
  contactName: z.string().min(2, "Contact name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(6, "Phone number is required"),
  productType: z.string().min(1, "Please select a product"),
  material: z.string().min(1, "Please select a material"),
  quantity: z.string().min(1, "Quantity is required"),
  destination: z.string().min(2, "Destination is required"),
  details: z.string().optional(),
});

export default function Contact() {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: "",
      contactName: "",
      email: "",
      phone: "",
      quantity: "",
      destination: "",
      details: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Mock submission
    console.log(values);
    setTimeout(() => {
      toast({
        title: "Quote Request Sent",
        description: "Thank you for your interest. Our sales team will contact you shortly.",
      });
      form.reset();
    }, 1500);
  }

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h4 className="text-primary font-bold uppercase tracking-widest mb-2">Get A Quote</h4>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-6">
              Partner with <br/>Satyu Polypack
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Ready to streamline your packaging supply? Fill out the form to request bulk pricing and export details. We respond to all RFQs within 24 hours.
            </p>

            <div className="bg-slate-50 p-8 rounded-lg border border-slate-100">
              <h3 className="text-xl font-bold text-slate-900 mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500 uppercase tracking-wide font-semibold">Location</p>
                  <p className="text-lg text-slate-800">Daman, India</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 uppercase tracking-wide font-semibold">Email</p>
                  <p className="text-lg text-slate-800">sales@satyupolypack.com</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 uppercase tracking-wide font-semibold">Business Hours</p>
                  <p className="text-lg text-slate-800">Mon - Sat: 9:00 AM - 6:00 PM IST</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 shadow-xl border border-gray-100 rounded-none relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-accent"></div>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your Company Ltd." {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="contactName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Person</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john@company.com" {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+1 (555) 000-0000" {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="productType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Interest</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="rounded-none bg-slate-50 border-slate-200 focus:border-primary">
                              <SelectValue placeholder="Select Product" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="garbage_bags">Garbage Bags</SelectItem>
                            <SelectItem value="shopping_bags">Shopping Bags</SelectItem>
                            <SelectItem value="liners">Industrial Liners</SelectItem>
                            <SelectItem value="stretch_film">Stretch Wrap / Film</SelectItem>
                            <SelectItem value="biohazard">Biohazard Bags</SelectItem>
                            <SelectItem value="custom">Custom Requirement</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="material"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Material Preference</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="rounded-none bg-slate-50 border-slate-200 focus:border-primary">
                              <SelectValue placeholder="Select Material" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="hdpe">HDPE</SelectItem>
                            <SelectItem value="ldpe">LDPE</SelectItem>
                            <SelectItem value="lldpe">LLDPE</SelectItem>
                            <SelectItem value="biodegradable">Biodegradable / Compostable</SelectItem>
                            <SelectItem value="recycled">Recycled</SelectItem>
                            <SelectItem value="unsure">Not Sure / Recommend</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estimated Quantity</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 1000 kgs / 50,000 pcs" {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="destination"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Destination Country</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. United Kingdom" {...field} className="rounded-none bg-slate-50 border-slate-200 focus:border-primary" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="details"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Specifications (Size, Micron, Printing)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please describe your specific requirements..." 
                          className="min-h-[100px] rounded-none bg-slate-50 border-slate-200 focus:border-primary"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={form.formState.isSubmitting}
                  className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-none text-lg transition-all"
                >
                  {form.formState.isSubmitting ? (
                    <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing Request...</>
                  ) : (
                    <><Send className="mr-2 h-5 w-5" /> Request Bulk Pricing</>
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}
