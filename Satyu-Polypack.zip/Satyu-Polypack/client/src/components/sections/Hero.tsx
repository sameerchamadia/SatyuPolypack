import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight, ChevronRight } from "lucide-react";
import heroBg from "@assets/generated_images/modern_plastic_manufacturing_factory_interior.png";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroBg} 
          alt="Modern Plastic Manufacturing Factory" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/40" />
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10 pt-20">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <div className="inline-block mb-4 px-3 py-1 bg-accent/20 border border-accent/30 rounded text-accent-foreground text-sm font-semibold tracking-wider uppercase backdrop-blur-sm">
            ISO 9001:2015 Certified Manufacturer
          </div>
          
          <h1 className="text-5xl md:text-7xl font-heading font-bold text-white leading-tight mb-6">
            Manufacturing Excellence & <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-green-400">
              Global Export Reliability
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl leading-relaxed">
            Satyu Polypack delivers high-quality plastic packaging solutions manufactured at scale. 
            Your trusted partner for bulk supply and international export.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              onClick={() => scrollToSection("products")}
              className="bg-primary hover:bg-primary/90 text-white font-bold px-8 py-6 text-lg rounded-none border-l-4 border-accent"
            >
              View Products
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => scrollToSection("contact")}
              className="bg-transparent border-white text-white hover:bg-white hover:text-slate-900 font-bold px-8 py-6 text-lg rounded-none transition-all"
            >
              Request a Quote <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </motion.div>
      </div>
      
      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ delay: 1, duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white/50"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-white to-transparent"></div>
        </div>
      </motion.div>
    </section>
  );
}
