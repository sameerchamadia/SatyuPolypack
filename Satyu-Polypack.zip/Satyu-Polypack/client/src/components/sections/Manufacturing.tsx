import { motion } from "framer-motion";
import factoryImg from "@assets/generated_images/close_up_plastic_extrusion_machine.png";
import { CheckCircle2 } from "lucide-react";

export default function Manufacturing() {
  return (
    <section id="manufacturing" className="py-0 bg-slate-900 text-white overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[600px]">
        {/* Image Side */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="relative h-full min-h-[400px]"
        >
          <img 
            src={factoryImg} 
            alt="Advanced Plastic Extrusion Machinery" 
            className="absolute inset-0 w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-transparent to-transparent lg:bg-gradient-to-t" />
        </motion.div>

        {/* Content Side */}
        <div className="flex flex-col justify-center p-12 lg:p-24 bg-slate-900">
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h4 className="text-accent font-bold uppercase tracking-widest mb-2">Our Facility</h4>
            <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-8">
              State-of-the-Art <br/>Manufacturing in Daman
            </h2>
            
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              Our Daman facility is equipped with the latest extrusion technology, enabling us to maintain tight control over thickness, strength, and finish quality. We are built for volume.
            </p>

            <ul className="space-y-4">
              {[
                "Advanced High-Speed Extrusion Machinery",
                "Large Production Capacity for Bulk Orders",
                "Automated Cutting & Sealing Units",
                "Strict In-House Quality Assurance Lab",
                "Export-Ready Packaging & Logistics"
              ].map((item, i) => (
                <li key={i} className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-accent mr-3 shrink-0" />
                  <span className="text-gray-200 text-lg">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
