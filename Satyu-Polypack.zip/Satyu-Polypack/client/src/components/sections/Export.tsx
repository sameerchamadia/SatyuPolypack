import { motion } from "framer-motion";
import { Globe2, Ship, FileCheck, Anchor } from "lucide-react";

export default function Export() {
  return (
    <section id="export" className="py-24 bg-primary text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]" />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            Global Export & Compliance
          </h2>
          <p className="text-blue-100 text-xl leading-relaxed">
            We understand the complexities of international trade. Satyu Polypack is positioned as your reliable partner for global logistics and seamless supply chain integration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <motion.div 
            whileHover={{ y: -5 }}
            className="p-8 bg-white/5 border border-white/10 backdrop-blur-sm rounded-lg"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6 text-accent">
              <Globe2 size={32} />
            </div>
            <h3 className="text-2xl font-heading font-bold mb-3">International Standards</h3>
            <p className="text-blue-100">
              Manufacturing processes aligned with global quality benchmarks to ensure product acceptance in diverse markets.
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="p-8 bg-white/5 border border-white/10 backdrop-blur-sm rounded-lg"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6 text-accent">
              <FileCheck size={32} />
            </div>
            <h3 className="text-2xl font-heading font-bold mb-3">Export Documentation</h3>
            <p className="text-blue-100">
              Full support with export documentation, certifications, and compliance requirements for hassle-free customs clearance.
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="p-8 bg-white/5 border border-white/10 backdrop-blur-sm rounded-lg"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6 text-accent">
              <Anchor size={32} />
            </div>
            <h3 className="text-2xl font-heading font-bold mb-3">Logistics Partnerships</h3>
            <p className="text-blue-100">
              Strategic tie-ups with major logistics providers to ensure timely delivery to any port worldwide.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
