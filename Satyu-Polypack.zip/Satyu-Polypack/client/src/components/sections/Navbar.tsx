import { useState } from "react";
import { Menu, X, Globe, Factory, Truck, CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsOpen(false);
    }
  };

  return (
    <nav className="fixed w-full z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center" onClick={() => scrollToSection("hero")}>
            <a href="#" className="text-2xl font-heading font-bold text-primary tracking-tight cursor-pointer">
              SATYU POLYPACK
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection("about")} className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection("products")} className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">
              Products
            </button>
            <button onClick={() => scrollToSection("manufacturing")} className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">
              Manufacturing
            </button>
            <button onClick={() => scrollToSection("export")} className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">
              Exports
            </button>
            <Button 
              onClick={() => scrollToSection("contact")}
              className="bg-primary hover:bg-primary/90 text-white font-medium px-6"
            >
              Get a Quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 hover:text-primary">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-gray-100 overflow-hidden"
          >
            <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
              <button onClick={() => scrollToSection("about")} className="text-base font-medium text-gray-600 py-2">
                About
              </button>
              <button onClick={() => scrollToSection("products")} className="text-base font-medium text-gray-600 py-2">
                Products
              </button>
              <button onClick={() => scrollToSection("manufacturing")} className="text-base font-medium text-gray-600 py-2">
                Manufacturing
              </button>
              <button onClick={() => scrollToSection("export")} className="text-base font-medium text-gray-600 py-2">
                Exports
              </button>
              <Button onClick={() => scrollToSection("contact")} className="w-full bg-primary text-white">
                Get a Quote
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
